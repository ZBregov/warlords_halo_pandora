//GOM_fnc_aircraftLoadout V1.35 made by Grumpy Old Man 17-5-2017


class GOM
{

	class init

	{

		class aircraftLoadoutParameters{file = "scripts\GOM\functions\GOM_fnc_aircraftLoadoutParameters.sqf";preInit = 1;};
		class aircraftLoadoutInit{file = "scripts\GOM\functions\GOM_fnc_aircraftLoadoutInit.sqf";preInit = 1;};

	};

};
