
# Warlords Redux 2.2
Warlords Redux 2.2 is a community upgrade project for the Original Warlords Redux. 

Original Warlords Redux by Bohemia Interactive and Jezuro can be found here:
https://steamcommunity.com/sharedfiles/filedetails/?id=1834482266&searchtext=Warlords+redux

Offical Arma 3 Website: https://arma3.com/

Offical Arma 3 discord:  https://discord.gg/arma

## Warlords Redux 2.2 

Warlords Redux 2.2 project goal is to improve on BI vision of warlords with bugfixes and more balanced user experience while staying compatable with official servers for the best player count.

Warlord Redux 2.0 discord: https://discord.gg/grmzsZE4ua

Warlords Redux Server info: https://www.battlemetrics.com/servers/arma3/5449720

## Want to get involed  

Github page: you are already here :)

Check this video out by Gamer Dad to help you get started: https://www.youtube.com/watch?v=tVIDyepo2WE , more to come as the workflow becomes more complex.